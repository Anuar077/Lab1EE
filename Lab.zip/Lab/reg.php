<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Reg</title>
  <link rel="stylesheet" href="css/main.css">
</head>
<body>
          <a class="" href="index.php">Главная</a>
      <a class="" href="auth.php">Войти</a>
      <a class="" href="reg.php">Регистрация</a>
    <div class="main">
      <h4>Please complate this form to register:</h4><!-- h4 for the heading   -->
      <form action="php/reg.php" method="post"><!-- action-specify the file to which variables will be passed;metho-method for passing variables, POST method-->
        <label for="email" id="email"  >Email adress</label>
							<?php  if (isset($_SESSION['email'])){"Write email"} ?>
        <input type="text" name="email" id="email" ><!-- input to fill in  data,type which type you want,placeholder its int -->
      <br><br><!-- for indentation -->
      <label for="pass">Password</label>
        <input type="password" id="pass" name="pass" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,30}" title="Write one number and one uppercase and lowercase letter, and at least 8 or more characters" required>
      <br><br><!-- for indentation -->
      <input type="submit" id="reg_user" value="Submit"><!-- input type is the submit ,for click-->
      <input type="reset" value="Clear"><!-- input type is the submit ,for click-->
      </form><!-- close tags-->
        </div><!-- close tags-->

<?php
$email = $_POST['email'];// reads the data;
if (isset($_POST['email'])){//checking that the email field was filled in;
if (filter_var($email, FILTER_VALIDATE_EMAIL)) ////  FILTER_VALIDATE_EMAIL Checks that the value is a valid e-mail address;
{
 echo "Email correct;";//outputs the text correctly
 echo "<br>";//space
} else {
 echo "Wrong;";//outputs the text wrong
 echo "<br>";//space
}
}
?>
</body>
</html>
