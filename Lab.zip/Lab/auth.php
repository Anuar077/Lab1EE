<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Auth</title>
  <link rel="stylesheet" href="css/main.css">
</head>
<body>
  <a class="" href="index.php">Главная</a>
<a class="" href="auth.php">Войти</a>
<a class="" href="reg.php">Регистрация</a>

                <h4>Authorization</h4>
                <form action="php/auth.php" method="post">
                    <label for="login">Email</label>
                    <input type="text" name="email" id="email" class="form-control">

                    <label for="pass">Password</label>
                    <input type="password" name="pass" id="pass" class="form-control">

                    <div class="alert alert-danger mt-2" id="errorBlock"></div>

                    <button type="button" id="auth_user" class="btn btn-success mt-3">Submit</button>
                </form>
                <h2><?=$_COOKIE['login']?></h2>
                <button class="btn btn-danger" id="exit_btn">Exit</button>
            </div>

</body>

</html>
