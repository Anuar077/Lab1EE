<?php
$email = $_POST['email'];// reads the data;
$pas =  $_POST['pass'];// reads the data;
if (isset($_POST['email'])){//checking that the email field was filled in;
if (filter_var($email, FILTER_VALIDATE_EMAIL)) ////  FILTER_VALIDATE_EMAIL Checks that the value is a valid e-mail address;
{
 echo "Email correct;";//outputs the text correctly
 echo "<br>";//space
} else {
 echo "Wrong;";//outputs the text wrong
 echo "<br>";//space
}
}
if (isset($_POST['pass'])){
	if(!preg_match("/^[A-Za-z0-9]{8,}$/",$pass)){
		echo "Correct password $pass";
		echo "<br>";
	}else{
		echo"Wrong password $pass";
		echo "<br>";
	}
$hash = "whsnjvsoAmlDxclsa13151Sdcdsk1568sd";
$pass = md5($pass . $hash);//md5() is crypting;
echo "Password:$pass" ;
echo "<br>";//space
$len = strlen($_POST["pass"]);
if($len >= 8){
  echo "Correct";
   echo "<br>";//space
}else {
echo "Write at least 8 characters";
}
}
 echo "<br>";//space
$user = 'root';
$password = '';
$db = 'lab';
$host = 'localhost';
$dsn = 'mysql:host='.$host.';dbname='.$db;
$pdo = new PDO($dsn, $user, $password);
$sql = "INSERT INTO hash(email, pass) VALUES('$email','$pass')";
$query = $pdo->prepare($sql);
$query->execute([ $email,$pass]);

echo 'Welcome';
?>
